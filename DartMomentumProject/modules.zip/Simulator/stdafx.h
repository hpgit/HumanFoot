// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <stdio.h>
#include <tchar.h>

#include <iostream>
#include <string>
//using namespace std;

#include <VP/vphysics.h>



#include <boost/python.hpp>
#include <python.h>
using namespace boost::python;
namespace bp = boost::python;


// TODO: reference additional headers your program requires here
