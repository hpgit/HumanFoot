// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <stdio.h>
#include <tchar.h>

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
using namespace std;

#include <boost/python.hpp>
#include <python.h>
using namespace boost::python;
namespace bp = boost::python;

// TODO: reference additional headers your program requires here
